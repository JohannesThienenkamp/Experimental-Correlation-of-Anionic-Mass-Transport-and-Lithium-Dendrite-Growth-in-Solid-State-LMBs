close all;
clear all;
clc;

%% constants

kb = 1.380649E-23                                      %J/K
e = 1.602176634E-19                                    %C

%% user-input

prompt = {'Enter FOV / mm', 'Enter experiment time of one spectrum / s', 'Enter number of experiments', 'Enter time domain', 'Enter Error in %', 'Enter temperature / K', 'Enter voltage sampling rate / s/point', 'Enter voltage profile name'};
dlgtitle = 'Input';
dims = [1 50];
definput = {'4','513','46', '256', '5', '313.15', '20.18181818', 'POL'};
Input = inputdlg(prompt,dlgtitle,dims,definput);


FOV = str2double(Input(1,1))                                       %mm
dt = str2double(Input(2,1))                                        %s
N = str2double(Input(3,1))
td = str2double(Input(4,1))
Err = str2double(Input(5,1))/100;
T = str2double(Input(6,1))                                         %K
dtU = str2double(Input(7,1))                                       %s
POL = string(Input(8,1))

dz = FOV/td                                                        %mm
pV = round((dt-69)/dtU)

%% MRI data import from Topspin3.5pl7 (multicmd: fmc & .txt export using python script)

format long
d=uigetdir('','Choose Filefolder'); 
cd(d); 
pr=dir('*.txt');

formatspec = '%g%g';

for f = 1:N
    spectra = fopen(pr(f).name);
     for k = 1:10;
            fgetl(spectra); 
     end
     data(:,f) = fscanf(spectra, formatspec, [1, Inf]);   %all headlines were deleted by using 'for-loop' in before.
     fclose(spectra);
end

data = flipud(data)                                         %turning data in FOV around
     
%% Voltage data import from Zahner Zennium Pro (.txt export) 

table = readtable(POL);
Volt(:,1) = table(:,1);
Volt(:,2) = table(:,2);
Volt = table2array(Volt);

for vv = 1:size(Volt,1)/pV
    if vv == 1
        dv(1,1) = mean(Volt(1:pV,2))
    else
        dv(vv,1) = mean(Volt((vv-1)*pV+1:(vv-1)*pV+pV+1,2)) 
    end
end

%% Region of interest & data correction & normalizing

FWHM = max(data(:,1))/2
[I FWHMx1]=min(abs(data(1:td/2,1)-FWHM));
[I FWHMx2]=min(abs(data(td/2:td,1)-FWHM));
FWHMx2 = FWHMx2+td/2;
Center = (FWHMx2-FWHMx1)/2+FWHMx1;
r3 = Center-20;
r4 = Center+20;
M = mean(data(r3:r4,1));
Err1 = M*(1-Err)
Err2 = M*(1+Err)
dataErr = find(data(:,1)>Err1 & data(:,1)<Err2)
Corr = data(dataErr(1,1):dataErr(size(dataErr,1)),1)-M;
C = (data(dataErr(1,1):dataErr(size(dataErr,1)),:)-Corr)/M;                              %mol/L = umol/mm3
z = (0:dz:FOV)'

%% data fitting, using polynomial fit (Taylor approximation)

for p = 1:size(C,2)
    C1(:,p) = polyfit(z(dataErr(1,1):dataErr(size(dataErr,1)),1),C(:,p),3)
    Cfit(:,p) = polyval(C1(:,p),z(dataErr(1,1):dataErr(size(dataErr,1)),1))          %mol/L    
end

Cfit = Cfit +0.666                                                          %corrected concentration, since EO:Li+ ratio = 10:1
t = (0:dt:(size(Cfit,2)-1)*dt)

for tn = 1:size(Cfit,1)
    C2(tn,:) = polyfit(t,Cfit(tn,:),3)
    Cfit(tn,:) = polyval(C2(tn,:),t)
end

%% Calculating diffusion coefficients D(z,t) & ion mobilities u(z,t)
% The fitting function is a third order polynomial function from 5 PFG
% experiments with different EO:Li ratio (10:1 --> 20:1)
% ion mobilities are calculated using Nernst-Einstein relation

D = -3.09546E-16.*Cfit.^3 - 8.14922E-15.*Cfit.^2 + 5.01302E-13.*Cfit - 2.57336E-12

u = 1E6.*D.*e./(kb.*T)                               %mm^2/s V

%% Calculating effective particle flow density Jeff & dc/dz
% using central differencial quotient & numerical integration

dcdt = gradient(Cfit, dt);
dcdt = dcdt.*(-1)./1E6                                  %mol/mm^3 s
Jeff = cumtrapz(dz, dcdt)                               %mol/mm^2 s

Cf = Cfit'
Cf = Cf./1E6                                            %mol/mm^3
dcdz = gradient(Cf, dz)                                 %mol/mm^4
dcdz = dcdz'
Cf = Cf'

%% Solving initial value problem arised from numerical integration
% calculating electric field E(z,t) & the overall voltage
% the overall voltage U(t) is the space integral of E(z) for each time (t)

E = (-1.*u.*dcdz.*kb.*T./e-Jeff)./u./Cf                   %V/mm

U = trapz(dz, E)                                         %V

for uu = 1:size(U,2)
    dU(1,uu) = (dv(uu,1)-U(1,uu))                        %V
end

% calculating corrected effective particle flow density Jeffc
% using dU as a boundary condition to solve B

B = dU./(trapz(dz,(1./(u.*Cf))))                    %mol mm^-2 s^-1
Jeffc = Jeff + B

JDiff = (u.*dcdz.*kb.*T./e).*(-1)
JMig = Jeffc - JDiff 
va = JMig./Cf.*1000.*3600

%% graphs

dxT = round(3600/dt)
xTL = ceil(N/dxT)
xT = xTL*dxT
r = dataErr(size(dataErr,1))-dataErr(1,1)

z1 = floor(min(min(Cfit))*10)/10
z2 = ceil(max(max(Cfit))*10)/10


f1 = figure(1);
f1.Color = [1 1 1];
ax1 = axes(f1)
p1 = surf(ax1, Cfit);
ax1.GridAlpha = 1
ax1.XLim = [0 xT]
ax1.XTick = [0:dxT:xT]
ax1.XTickLabel = [2.5:1:xTL+2.5]
ax1.YLim = [0 r]
ax1.YTick = [0:r/4:r]
ax1.YTickLabel = [0:1/4:1]
ax1.XLabel.String = '\bf\itt\rm\bf / h'
ax1.XLabel.FontSize = 24
ax1.XAxis.LineWidth = 3
ax1.XLabel.FontName = 'Arial Black'
ax1.XLabel.Position = [18,0,1.465]
ax1.XLabel.Rotation = [0]
ax1.FontWeight = 'bold'
ax1.FontSize = 22
ax1.YLabel.String = '\bf\it L'
ax1.YLabel.FontSize = 24
ax1.YAxis.LineWidth = 3
ax1.YLabel.FontName = 'Arial Black'
ax1.YLabel.Position = [69,0,1.54]
ax1.ZLim =[z1 z2]
ax1.ZTick = [z1:(z2-z1)/4:z2]
ax1.ZLabel.String = '\bf\it C\rm\bf_{a} / mol L^{-1}'
ax1.ZLabel.FontSize = 24
ax1.ZAxis.LineWidth = 3
ax1.ZLabel.FontName = 'Arial Black'
ax1.ZLabel.Position = [-6,0,1.7]
ax1.CameraPosition = [271.5980001554803,-498.963103327729,2.658452853561498]
p1.MeshStyle = 'colum'
l1 = light(ax1)
l1.Position = [6.5 -750 10]
p1.FaceLighting = 'gouraud'
material dull
colormap parula

f2 = figure(2);
f2.Color = [1 1 1];
ax2 = axes(f2)
p2 = surf(ax2, va);
ax2.GridAlpha = 1
ax2.XLim = [0 xT]
ax2.XTick = [0:dxT:xT]
ax2.XTickLabel = [2.5:1:xTL+2.5]
ax2.YLim = [0 r]
ax2.YTick = [0:r/4:r]
ax2.YTickLabel = [0:1/4:1]
ax2.XLabel.String = '\bf\itt\rm\bf / h'
ax2.XLabel.FontSize = 32
ax2.XAxis.LineWidth = 5
ax2.XLabel.FontName = 'Arial Black'
ax2.XLabel.Position = [23,0,-440]
ax2.XLabel.Rotation = [0]
ax2.FontWeight = 'bold'
ax2.FontSize = 32
ax2.YLabel.String = '\bf\it x\rm\bf_{i}'
ax2.YLabel.FontSize = 32
ax2.YAxis.LineWidth = 5
ax2.YLabel.FontName = 'Arial Black'
ax2.YLabel.Position = [62,0,-350]
ax2.ZLabel.String = '\bf\it v\rm\bf_{a} / \mum h^{-1}'
ax2.ZLabel.FontSize = 32
ax2.ZAxis.LineWidth = 5
ax2.ZLabel.FontName = 'Arial Black'
ax2.ZLabel.Position = [-6,0,-200]
ax2.CameraPosition = [123.2397857930967,-516.1030732748042,737.6830071055189]
l2 = light(ax2)
l2.Position = [8 -8 100]
p2.MeshStyle = 'colum'
p2.FaceLighting = 'gouraud'
material dull
colormap default
